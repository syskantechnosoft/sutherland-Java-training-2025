package com.example.secureapp.model;

public enum AuthProvider {
    local,
    google,
    github
}