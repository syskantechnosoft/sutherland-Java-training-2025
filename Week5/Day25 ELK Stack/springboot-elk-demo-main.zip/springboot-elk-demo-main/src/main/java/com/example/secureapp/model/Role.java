package com.example.secureapp.model;

public enum Role {
    USER,
    ADMIN
}